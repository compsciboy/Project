[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-f059dc9a6f8d3a56e377f745f24479a46679e63a5d9fe6f495e02850cd0d8118.svg)](https://classroom.github.com/online_ide?assignment_repo_id=6403478&assignment_repo_type=AssignmentRepo)
# Scrabble

Please import all your files from the previous homeworks.
Please edit this file with a link to your deployed Heroku app, and commit a screenshot of your application under the filename `myScrabbleGame.jpg`.


Heroku app line: https://git.heroku.com/hw-ten.git
